# CNAPP PoC – Terraform Lab

Environnement de test CNAPP couvrant les familles **General / CIEM / CWPP / IaC / Secrets**,
déployable sur **AWS `eu-west-1`** et **Azure `francecentral`**.

---

## Arborescence

```
cnapp-poc/
├── terraform/
│   ├── aws/            # VPC, EC2, ECS Fargate, ECR, Lambda+APIGW, IAM, CloudTrail
│   ├── azure/          # VNet, VM, ACI, ACR, Azure Function, Entra ID, Log Analytics
│   └── modules/
│       └── compute/    # Module avec misconfiguration intentionnelle (IAC-02)
├── pipelines/
│   └── lambda/         # handler.py + requirements.txt (dépendance vulnérable CWPP-03)
├── scripts/
│   ├── build_images.sh      # Build & push des 3 images Docker (ECR + ACR)
│   ├── trigger_drift.sh     # Crée un drift IaC sur AWS et Azure (IAC-06)
│   └── inject_git_secret.sh # Injecte un faux secret dans l'historique git (SS-07)
├── .github/
│   └── workflows/
│       └── iac-scan.yml     # Pipeline GitHub Actions (scan IaC + secrets + gating)
└── docs/
    └── README.md
```

---

## Prérequis

| Outil         | Version minimale |
|---------------|-----------------|
| Terraform     | >= 1.5          |
| AWS CLI       | >= 2.x          |
| Azure CLI     | >= 2.x          |
| Docker        | >= 24.x         |
| Git           | >= 2.x          |

---

## Variables à renseigner

### `terraform/aws/terraform.tfvars`

```hcl
ssh_public_key = "ssh-rsa AAAA..."
prefix         = "cnapp-poc"
aws_region     = "eu-west-1"
az             = "eu-west-1a"
```

### `terraform/azure/terraform.tfvars`

```hcl
ssh_public_key      = "ssh-rsa AAAA..."
prefix              = "cnapp-poc"
azure_location      = "francecentral"
resource_group_name = "rg-cnapp-poc"
admin_username      = "azureuser"
tenant_domain       = "contoso.onmicrosoft.com"  # votre domaine Entra ID par défaut
```

---

## Déploiement AWS

```bash
export AWS_PROFILE=cnapp-poc   # ou configurez AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY

cd terraform/aws
terraform init
terraform plan  -out tfplan-aws
terraform apply tfplan-aws
```

## Déploiement Azure

```bash
az login
az account set --subscription "YOUR_SUBSCRIPTION_ID"

cd terraform/azure
terraform init
terraform plan  -out tfplan-azure
terraform apply tfplan-azure
```

---

## Étapes post-déploiement

### 1. Build & push des images Docker

```bash
bash scripts/build_images.sh
```

### 2. Connecter les clouds à la CNAPP

- **AWS** : créer un rôle cross-account IAM (read-only + SecurityAudit) et fournir l'ARN à la solution.
- **Azure** : créer un Service Principal Reader sur la subscription et fournir les credentials.

### 3. Créer un drift IaC (IAC-06)

```bash
bash scripts/trigger_drift.sh
```

### 4. Tester CIEM-07 (break-glass)

```bash
# Créer un profil AWS CLI pour le break-glass, puis :
aws sts get-caller-identity --profile cnapp-poc-breakglass
aws s3 ls                    --profile cnapp-poc-breakglass
```

Vérifier l'alerte dans la CNAPP dans les minutes qui suivent.

### 5. Injecter des secrets dans l'historique git (SS-01/SS-07)

```bash
bash scripts/inject_git_secret.sh --push
```

---

## Nettoyage

```bash
# Azure
cd terraform/azure && terraform destroy -auto-approve

# AWS
cd terraform/aws   && terraform destroy -auto-approve
```

---

## Profil coût estimé (baseline 24/7)

| Ressource                     | Coût/mois estimé |
|-------------------------------|-----------------|
| 3× EC2 t3.micro (eu-west-1)   | ~12 €           |
| ECS Fargate 3×256/512         | ~18 €           |
| Lambda + API Gateway          | < 1 €           |
| ECR + CloudTrail + S3         | ~3 €            |
| **Total AWS**                 | **~34 €**       |
| 3× VM Standard_B1s (FR)       | ~15 €           |
| 3× ACI 0.25vCPU/0.5GB        | ~10 €           |
| Azure Function (Consumption)  | < 1 €           |
| ACR Basic + Log Analytics     | ~8 €            |
| **Total Azure**               | **~34 €**       |
| **TOTAL PoC**                 | **~68 €/mois**  |

> **Astuce** : arrêtez les EC2/VM et les services ECS/ACI entre les sessions de test pour réduire les coûts à < 5 €/session.

---

## Avertissement sécurité

Ce repo contient des configurations **volontairement vulnérables** (ports ouverts, secrets factices, images non patchées).  
Il est destiné **exclusivement** à un usage PoC dans un compte isolé.  
Ne jamais déployer dans un environnement de production ou partagé.  
Tous les secrets présents sont **fictifs** et n'ont aucune valeur opérationnelle.

variable "azure_location" {
  description = "Azure region"
  type        = string
  default     = "francecentral"
}

variable "prefix" {
  description = "Prefix for all resource names"
  type        = string
  default     = "cnapp-poc"
}

variable "resource_group_name" {
  description = "Azure resource group name"
  type        = string
  default     = "rg-cnapp-poc"
}

variable "admin_username" {
  description = "Admin username for Azure VMs"
  type        = string
  default     = "azureuser"
}

variable "ssh_public_key" {
  description = "SSH public key for Azure VMs"
  type        = string
}

variable "tags" {
  description = "Common tags applied to all resources"
  type        = map(string)
  default = {
    Project     = "cnapp-poc"
    Environment = "poc"
    ManagedBy   = "terraform"
  }
}

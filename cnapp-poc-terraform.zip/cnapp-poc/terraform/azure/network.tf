# ──────────────────────────────────────────────────────────────────────────────
# VNet
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_virtual_network" "poc" {
  name                = "${var.prefix}-vnet"
  address_space       = ["10.20.0.0/16"]
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name
  tags                = var.tags
}

# ──────────────────────────────────────────────────────────────────────────────
# Subnets
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_subnet" "expose" {
  name                 = "subnet-expose"
  resource_group_name  = azurerm_resource_group.poc.name
  virtual_network_name = azurerm_virtual_network.poc.name
  address_prefixes     = ["10.20.1.0/24"]
}

resource "azurerm_subnet" "restreint" {
  name                 = "subnet-restreint"
  resource_group_name  = azurerm_resource_group.poc.name
  virtual_network_name = azurerm_virtual_network.poc.name
  address_prefixes     = ["10.20.2.0/24"]
}

# ──────────────────────────────────────────────────────────────────────────────
# NSG – Exposé (CWPP-01/02/03, IAC-01/03 – misconfig intentionnelle)
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_network_security_group" "expose" {
  name                = "${var.prefix}-nsg-expose"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name

  security_rule {
    name                       = "SSH-world-open"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "22"
    source_address_prefix      = "*" # Intentionnel
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "HTTP-world-open"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "80"
    source_address_prefix      = "*" # Intentionnel
    destination_address_prefix = "*"
  }

  security_rule {
    name                       = "App-8080"
    priority                   = 120
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "8080"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }

  tags = var.tags
}

# ──────────────────────────────────────────────────────────────────────────────
# NSG – Restreint (aucun inbound externe)
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_network_security_group" "restreint" {
  name                = "${var.prefix}-nsg-restrict"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name
  tags                = var.tags
}

resource "azurerm_subnet_network_security_group_association" "expose" {
  subnet_id                 = azurerm_subnet.expose.id
  network_security_group_id = azurerm_network_security_group.expose.id
}

resource "azurerm_subnet_network_security_group_association" "restreint" {
  subnet_id                 = azurerm_subnet.restreint.id
  network_security_group_id = azurerm_network_security_group.restreint.id
}

# ──────────────────────────────────────────────────────────────────────────────
# Log Analytics Workspace
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_log_analytics_workspace" "poc" {
  name                = "${var.prefix}-law"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name
  sku                 = "PerGB2018"
  retention_in_days   = 30
  tags                = var.tags
}

# ──────────────────────────────────────────────────────────────────────────────
# Entra ID Diagnostic Settings → Log Analytics (CIEM-07/08/10)
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_monitor_aad_diagnostic_setting" "entra" {
  name                       = "${var.prefix}-entra-diag"
  log_analytics_workspace_id = azurerm_log_analytics_workspace.poc.id

  enabled_log { category = "AuditLogs" }
  enabled_log { category = "SignInLogs" }
  enabled_log { category = "RiskyUsers" }
}

# ──────────────────────────────────────────────────────────────────────────────
# Storage Account – Drift IaC (IAC-06)
# Déployé via Terraform (https_only=true) puis modifié manuellement
# (https_only passé à false via le portail) pour créer un drift détectable.
# ──────────────────────────────────────────────────────────────────────────────
locals {
  drift_sa_name = lower(replace("${var.prefix}driftsa", "-", ""))
}

resource "azurerm_storage_account" "drift_target" {
  name                     = local.drift_sa_name
  resource_group_name      = azurerm_resource_group.poc.name
  location                 = azurerm_resource_group.poc.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  https_traffic_only_enabled = true # Sera passé à false manuellement pour IAC-06

  tags = merge(var.tags, { IaCDriftTest = "true" })
}

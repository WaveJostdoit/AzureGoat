locals {
  func_sa_name = lower(replace("${var.prefix}funcsa", "-", ""))
}

resource "azurerm_storage_account" "func" {
  name                     = local.func_sa_name
  resource_group_name      = azurerm_resource_group.poc.name
  location                 = azurerm_resource_group.poc.location
  account_tier             = "Standard"
  account_replication_type = "LRS"
  tags                     = var.tags
}

resource "azurerm_service_plan" "func" {
  name                = "${var.prefix}-func-plan"
  resource_group_name = azurerm_resource_group.poc.name
  location            = azurerm_resource_group.poc.location
  os_type             = "Linux"
  sku_name            = "Y1" # Consumption – coût minimal
  tags                = var.tags
}

# ──────────────────────────────────────────────────────────────────────────────
# Azure Function – vulnérable (CWPP-03, SS-02)
# Trigger HTTP public sans authentification, secret en app_settings
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_linux_function_app" "vuln" {
  name                = "${var.prefix}-func-vuln"
  resource_group_name = azurerm_resource_group.poc.name
  location            = azurerm_resource_group.poc.location

  storage_account_name       = azurerm_storage_account.func.name
  storage_account_access_key = azurerm_storage_account.func.primary_access_key
  service_plan_id            = azurerm_service_plan.func.id

  site_config {
    application_stack {
      python_version = "3.9"
    }
    # Pas de ip_restriction → exposition publique intentionnelle (CWPP-03)
  }

  app_settings = {
    # Secrets en app_settings – SS-02 intentionnel
    "DB_PASSWORD"                  = "SuperSecret123"
    "API_KEY"                      = "AKIAFAKEKEY123456"
    "FUNCTIONS_WORKER_RUNTIME"     = "python"
    "AzureWebJobsFeatureFlags"     = "EnableWorkerIndexing"
  }

  auth_settings {
    enabled = false # Trigger public sans auth – CWPP-03 intentionnel
  }

  tags = var.tags
}

# RBAC Contributor sur la Function pour le SP sur-privilégié (CIEM-06)
resource "azurerm_role_assignment" "func_sp_contributor" {
  scope                = azurerm_linux_function_app.vuln.id
  role_definition_name = "Contributor"
  principal_id         = azuread_service_principal.sa_overprivileged.id
}

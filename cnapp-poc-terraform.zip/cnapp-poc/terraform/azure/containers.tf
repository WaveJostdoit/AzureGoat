# ──────────────────────────────────────────────────────────────────────────────
# ACI – Vulnérable (CWPP-02)
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_container_group" "aci_vuln" {
  name                = "${var.prefix}-aci-vuln"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name
  ip_address_type     = "Public"
  dns_name_label      = "${var.prefix}-aci-vuln"
  os_type             = "Linux"
  restart_policy      = "Always"

  container {
    name   = "vuln-container"
    image  = "${azurerm_container_registry.poc.login_server}/image-vuln:latest"
    cpu    = "0.25"
    memory = "0.5"

    ports {
      port     = 80
      protocol = "TCP"
    }
  }

  image_registry_credential {
    server   = azurerm_container_registry.poc.login_server
    username = azurerm_container_registry.poc.admin_username
    password = azurerm_container_registry.poc.admin_password
  }

  tags = merge(var.tags, { Name = "aci-vuln", Role = "vulnerable" })
}

# ──────────────────────────────────────────────────────────────────────────────
# ACI – Secret exposé (SS-02/04)
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_container_group" "aci_secret" {
  name                = "${var.prefix}-aci-secret"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name
  ip_address_type     = "Public"
  dns_name_label      = "${var.prefix}-aci-secret"
  os_type             = "Linux"
  restart_policy      = "Always"

  container {
    name   = "secret-container"
    image  = "${azurerm_container_registry.poc.login_server}/image-secret:latest"
    cpu    = "0.25"
    memory = "0.5"

    ports {
      port     = 80
      protocol = "TCP"
    }

    # Secrets en variables d'env – SS-02/04 intentionnel
    environment_variables = {
      DB_PASSWORD = "SuperSecret123"
      API_KEY     = "fake-api-key-123"
    }
  }

  image_registry_credential {
    server   = azurerm_container_registry.poc.login_server
    username = azurerm_container_registry.poc.admin_username
    password = azurerm_container_registry.poc.admin_password
  }

  tags = merge(var.tags, { Name = "aci-secret", Role = "secret-exposed" })
}

# ──────────────────────────────────────────────────────────────────────────────
# ACI – Saine / référence (subnet restreint, pas d'IP publique)
# ──────────────────────────────────────────────────────────────────────────────

# Delegation requise pour ACI dans un subnet
resource "azurerm_subnet" "aci_clean" {
  name                 = "subnet-aci-clean"
  resource_group_name  = azurerm_resource_group.poc.name
  virtual_network_name = azurerm_virtual_network.poc.name
  address_prefixes     = ["10.20.3.0/24"]

  delegation {
    name = "aci-delegation"
    service_delegation {
      name    = "Microsoft.ContainerInstance/containerGroups"
      actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
    }
  }
}

resource "azurerm_container_group" "aci_clean" {
  name                = "${var.prefix}-aci-clean"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name
  ip_address_type     = "Private"
  subnet_ids          = [azurerm_subnet.aci_clean.id]
  os_type             = "Linux"
  restart_policy      = "Always"

  container {
    name   = "clean-container"
    image  = "${azurerm_container_registry.poc.login_server}/image-clean:latest"
    cpu    = "0.25"
    memory = "0.5"
  }

  image_registry_credential {
    server   = azurerm_container_registry.poc.login_server
    username = azurerm_container_registry.poc.admin_username
    password = azurerm_container_registry.poc.admin_password
  }

  tags = merge(var.tags, { Name = "aci-clean", Role = "clean-reference" })
}

# Name doit être alphanumérique unique globalement, max 50 chars
locals {
  acr_name = lower(replace("${var.prefix}acr", "-", ""))
}

resource "azurerm_container_registry" "poc" {
  name                = local.acr_name
  resource_group_name = azurerm_resource_group.poc.name
  location            = azurerm_resource_group.poc.location
  sku                 = "Basic"
  admin_enabled       = true # Simplifie les push PoC; désactiver en prod

  tags = var.tags
}

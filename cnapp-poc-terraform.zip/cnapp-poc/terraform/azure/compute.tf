# ──────────────────────────────────────────────────────────────────────────────
# VM – Vulnérable (CWPP-01)
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_public_ip" "vm_vuln" {
  name                = "${var.prefix}-pip-vm-vuln"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_network_interface" "vm_vuln" {
  name                = "${var.prefix}-nic-vm-vuln"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = azurerm_subnet.expose.id
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.vm_vuln.id
  }
}

resource "azurerm_linux_virtual_machine" "vm_vuln" {
  name                = "${var.prefix}-vm-vuln"
  resource_group_name = azurerm_resource_group.poc.name
  location            = azurerm_resource_group.poc.location
  size                = "Standard_B1s"
  admin_username      = var.admin_username

  network_interface_ids = [azurerm_network_interface.vm_vuln.id]

  admin_ssh_key {
    username   = var.admin_username
    public_key = var.ssh_public_key
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts"
    version   = "latest"
  }

  custom_data = base64encode(<<-EOF
    #!/bin/bash
    apt-get update -y
    systemctl disable unattended-upgrades || true
    apt-get install -y apache2
    systemctl enable apache2
    # SSH root login activé – misconfiguration intentionnelle (CWPP-01)
    sed -i 's/#PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
    systemctl restart sshd
  EOF
  )

  tags = merge(var.tags, { Name = "vm-vuln", Role = "vulnerable" })
}

# ──────────────────────────────────────────────────────────────────────────────
# VM – Secret exposé (SS-02)
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_public_ip" "vm_secret" {
  name                = "${var.prefix}-pip-vm-secret"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_network_interface" "vm_secret" {
  name                = "${var.prefix}-nic-vm-secret"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = azurerm_subnet.expose.id
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.vm_secret.id
  }
}

resource "azurerm_linux_virtual_machine" "vm_secret" {
  name                = "${var.prefix}-vm-secret"
  resource_group_name = azurerm_resource_group.poc.name
  location            = azurerm_resource_group.poc.location
  size                = "Standard_B1s"
  admin_username      = var.admin_username

  network_interface_ids = [azurerm_network_interface.vm_secret.id]

  admin_ssh_key {
    username   = var.admin_username
    public_key = var.ssh_public_key
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts"
    version   = "latest"
  }

  custom_data = base64encode(<<-EOF
    #!/bin/bash
    apt-get update -y
    # Secrets en variable d'environnement (SS-02 – intentionnel)
    echo 'API_KEY=fake-api-key-do-not-use'   >> /etc/environment
    echo 'DB_PASSWORD=SuperSecret123'         >> /etc/environment
    # Secret dans fichier avec permissions trop larges (SS-02 – intentionnel)
    mkdir -p /home/${var.admin_username}
    echo "db_password=SuperSecret123"         >  /home/${var.admin_username}/config.txt
    echo "password=SuperSecret123"            >> /home/${var.admin_username}/config.txt
    chmod 777 /home/${var.admin_username}/config.txt
  EOF
  )

  tags = merge(var.tags, { Name = "vm-secret", Role = "secret-exposed" })
}

# ──────────────────────────────────────────────────────────────────────────────
# VM – Saine / référence
# ──────────────────────────────────────────────────────────────────────────────
resource "azurerm_network_interface" "vm_clean" {
  name                = "${var.prefix}-nic-vm-clean"
  location            = azurerm_resource_group.poc.location
  resource_group_name = azurerm_resource_group.poc.name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = azurerm_subnet.restreint.id
    private_ip_address_allocation = "Dynamic"
  }
}

resource "azurerm_linux_virtual_machine" "vm_clean" {
  name                = "${var.prefix}-vm-clean"
  resource_group_name = azurerm_resource_group.poc.name
  location            = azurerm_resource_group.poc.location
  size                = "Standard_B1s"
  admin_username      = var.admin_username

  network_interface_ids = [azurerm_network_interface.vm_clean.id]

  admin_ssh_key {
    username   = var.admin_username
    public_key = var.ssh_public_key
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts"
    version   = "latest"
  }

  custom_data = base64encode(<<-EOF
    #!/bin/bash
    apt-get update -y && apt-get upgrade -y
    sed -i 's/#PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
    systemctl restart sshd
  EOF
  )

  tags = merge(var.tags, { Name = "vm-clean", Role = "clean-reference" })
}

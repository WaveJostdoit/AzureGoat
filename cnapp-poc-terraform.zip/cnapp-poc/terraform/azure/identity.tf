# ──────────────────────────────────────────────────────────────────────────────
# Groupes Entra ID
# ──────────────────────────────────────────────────────────────────────────────

resource "azuread_group" "developers" {
  display_name     = "${var.prefix}-developers"
  security_enabled = true
}

resource "azuread_group" "admins" {
  display_name     = "${var.prefix}-admins"
  security_enabled = true
}

resource "azuread_group" "security_analysts" {
  display_name     = "${var.prefix}-security-analysts"
  security_enabled = true
}

resource "azuread_group" "readonly" {
  display_name     = "${var.prefix}-readonly"
  security_enabled = true
}

# ──────────────────────────────────────────────────────────────────────────────
# Utilisateurs Entra ID
# NOTE: le domaine onmicrosoft.com est dérivé du tenant_id.
# Remplacez <TENANT_DEFAULT_DOMAIN> dans votre tfvars si vous avez un domaine custom.
# ──────────────────────────────────────────────────────────────────────────────

variable "tenant_domain" {
  description = "Default Entra ID domain (e.g. contoso.onmicrosoft.com)"
  type        = string
}

resource "azuread_user" "standard" {
  count                 = 3
  user_principal_name   = "${var.prefix}-user-standard-${count.index + 1}@${var.tenant_domain}"
  display_name          = "Standard User ${count.index + 1}"
  password              = "P@ssw0rd-poc-std-${count.index + 1}!"
  force_password_change = false
}

resource "azuread_user" "overprivileged" {
  user_principal_name   = "${var.prefix}-user-overprivileged@${var.tenant_domain}"
  display_name          = "Over-Privileged User"
  password              = "P@ssw0rd-poc-ovr!"
  force_password_change = false
}

resource "azuread_user" "admin" {
  user_principal_name   = "${var.prefix}-user-admin@${var.tenant_domain}"
  display_name          = "Admin User"
  password              = "P@ssw0rd-poc-adm!"
  force_password_change = false
}

# CIEM-04/07 : break-glass, normalement inutilisé
resource "azuread_user" "breakglass" {
  user_principal_name   = "${var.prefix}-break-glass@${var.tenant_domain}"
  display_name          = "Break Glass Account"
  password              = "P@ssw0rd-poc-bg!"
  force_password_change = false
}

# CIEM-03 : appartient à 2 groupes
resource "azuread_user" "multirole" {
  user_principal_name   = "${var.prefix}-user-multirole@${var.tenant_domain}"
  display_name          = "Multi-Role User"
  password              = "P@ssw0rd-poc-mlt!"
  force_password_change = false
}

resource "azuread_user" "readonly" {
  count                 = 2
  user_principal_name   = "${var.prefix}-user-readonly-${count.index + 1}@${var.tenant_domain}"
  display_name          = "Read-Only User ${count.index + 1}"
  password              = "P@ssw0rd-poc-ro-${count.index + 1}!"
  force_password_change = false
}

# ──────────────────────────────────────────────────────────────────────────────
# Memberships
# ──────────────────────────────────────────────────────────────────────────────

resource "azuread_group_member" "standard_dev" {
  count            = 3
  group_object_id  = azuread_group.developers.id
  member_object_id = azuread_user.standard[count.index].id
}

# Double appartenance developers + admins → CIEM-05 (permission overlap)
resource "azuread_group_member" "overprivileged_admins" {
  group_object_id  = azuread_group.admins.id
  member_object_id = azuread_user.overprivileged.id
}

resource "azuread_group_member" "overprivileged_dev" {
  group_object_id  = azuread_group.developers.id
  member_object_id = azuread_user.overprivileged.id
}

resource "azuread_group_member" "admin_admins" {
  group_object_id  = azuread_group.admins.id
  member_object_id = azuread_user.admin.id
}

# developers + readonly → CIEM-03 (effective permissions)
resource "azuread_group_member" "multirole_dev" {
  group_object_id  = azuread_group.developers.id
  member_object_id = azuread_user.multirole.id
}

resource "azuread_group_member" "multirole_readonly" {
  group_object_id  = azuread_group.readonly.id
  member_object_id = azuread_user.multirole.id
}

resource "azuread_group_member" "readonly_grp" {
  count            = 2
  group_object_id  = azuread_group.readonly.id
  member_object_id = azuread_user.readonly[count.index].id
}

# ──────────────────────────────────────────────────────────────────────────────
# RBAC Azure subscription
# ──────────────────────────────────────────────────────────────────────────────

# CIEM-04 : Owner sur la subscription → high-privilege détectable
resource "azurerm_role_assignment" "admin_owner" {
  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Owner"
  principal_id         = azuread_user.admin.id
}

# CIEM-04/07 : break-glass Owner
resource "azurerm_role_assignment" "breakglass_owner" {
  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Owner"
  principal_id         = azuread_user.breakglass.id
}

# CIEM-05/06 : Contributor sur toute la subscription
resource "azurerm_role_assignment" "overprivileged_contributor" {
  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Contributor"
  principal_id         = azuread_user.overprivileged.id
}

# ──────────────────────────────────────────────────────────────────────────────
# Service Principals (machine identities)
# ──────────────────────────────────────────────────────────────────────────────

resource "azuread_application" "sa_overprivileged" {
  display_name = "${var.prefix}-sa-overprivileged"
}

resource "azuread_service_principal" "sa_overprivileged" {
  client_id = azuread_application.sa_overprivileged.client_id
}

# CIEM-06/12 : Contributor subscription-wide → SP trop permissif
resource "azurerm_role_assignment" "sa_overprivileged_contributor" {
  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Contributor"
  principal_id         = azuread_service_principal.sa_overprivileged.id
}

resource "azuread_application" "sa_standard" {
  display_name = "${var.prefix}-sa-standard"
}

resource "azuread_service_principal" "sa_standard" {
  client_id = azuread_application.sa_standard.client_id
}

resource "azurerm_role_assignment" "sa_standard_reader" {
  scope                = azurerm_resource_group.poc.id
  role_definition_name = "Reader"
  principal_id         = azuread_service_principal.sa_standard.id
}

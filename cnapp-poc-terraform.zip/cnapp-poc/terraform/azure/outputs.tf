output "resource_group_name" {
  description = "Azure resource group name"
  value       = azurerm_resource_group.poc.name
}

output "vm_vuln_public_ip" {
  description = "Public IP of vm-vuln (CWPP-01)"
  value       = azurerm_public_ip.vm_vuln.ip_address
}

output "vm_secret_public_ip" {
  description = "Public IP of vm-secret (SS-02)"
  value       = azurerm_public_ip.vm_secret.ip_address
}

output "acr_login_server" {
  description = "ACR login server URL"
  value       = azurerm_container_registry.poc.login_server
}

output "acr_admin_username" {
  description = "ACR admin username"
  value       = azurerm_container_registry.poc.admin_username
  sensitive   = true
}

output "func_vuln_default_hostname" {
  description = "Azure Function default hostname (CWPP-03)"
  value       = azurerm_linux_function_app.vuln.default_hostname
}

output "drift_storage_account" {
  description = "Storage account name used for IaC drift test (IAC-06)"
  value       = azurerm_storage_account.drift_target.name
}

output "aci_vuln_fqdn" {
  description = "ACI vuln public FQDN (CWPP-02)"
  value       = azurerm_container_group.aci_vuln.fqdn
}

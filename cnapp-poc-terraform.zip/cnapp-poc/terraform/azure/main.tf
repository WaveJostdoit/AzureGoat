terraform {
  required_version = ">= 1.5"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.47"
    }
  }
}

provider "azurerm" {
  features {}
}

provider "azuread" {}

data "azuread_client_config" "current" {}
data "azurerm_subscription" "current" {}

resource "azurerm_resource_group" "poc" {
  name     = var.resource_group_name
  location = var.azure_location
  tags     = var.tags
}

# ──────────────────────────────────────────────────────────────────────────────
# ECS Cluster
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_ecs_cluster" "poc" {
  name = "${var.prefix}-cluster"
  tags = var.tags
}

# ──────────────────────────────────────────────────────────────────────────────
# ECS Task Execution Role
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_iam_role" "ecs_execution" {
  name = "${var.prefix}-ecs-execution-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "ecs_execution" {
  role       = aws_iam_role.ecs_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

# ECR pull permission for execution role
resource "aws_iam_role_policy" "ecs_ecr_pull" {
  name = "ecr-pull"
  role = aws_iam_role.ecs_execution.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["ecr:GetAuthorizationToken", "ecr:BatchCheckLayerAvailability", "ecr:GetDownloadUrlForLayer", "ecr:BatchGetImage"]
      Resource = "*"
    }]
  })
}

# ──────────────────────────────────────────────────────────────────────────────
# ECS Task Definitions
# ──────────────────────────────────────────────────────────────────────────────

resource "aws_ecs_task_definition" "vuln" {
  family                   = "${var.prefix}-ecs-vuln"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.ecs_execution.arn
  task_role_arn            = aws_iam_role.sa_overprivileged.arn

  container_definitions = jsonencode([{
    name  = "vuln-container"
    image = "${aws_ecr_repository.poc.repository_url}:image-vuln"
    portMappings = [{ containerPort = 80, protocol = "tcp" }]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = "/ecs/${var.prefix}-vuln"
        "awslogs-region"        = var.aws_region
        "awslogs-stream-prefix" = "ecs"
      }
    }
  }])

  tags = var.tags
}

resource "aws_cloudwatch_log_group" "ecs_vuln" {
  name              = "/ecs/${var.prefix}-vuln"
  retention_in_days = 7
  tags              = var.tags
}

resource "aws_ecs_task_definition" "secret" {
  family                   = "${var.prefix}-ecs-secret"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.ecs_execution.arn
  task_role_arn            = aws_iam_role.sa_standard.arn

  container_definitions = jsonencode([{
    name  = "secret-container"
    image = "${aws_ecr_repository.poc.repository_url}:image-secret"
    # Variables d'env avec secrets – SS-02/04 intentionnel
    environment = [
      { name = "DB_PASSWORD", value = "SuperSecret123" },
      { name = "API_KEY",     value = "fake-api-key-123" }
    ]
    portMappings = [{ containerPort = 80, protocol = "tcp" }]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = "/ecs/${var.prefix}-secret"
        "awslogs-region"        = var.aws_region
        "awslogs-stream-prefix" = "ecs"
      }
    }
  }])

  tags = var.tags
}

resource "aws_cloudwatch_log_group" "ecs_secret" {
  name              = "/ecs/${var.prefix}-secret"
  retention_in_days = 7
  tags              = var.tags
}

resource "aws_ecs_task_definition" "clean" {
  family                   = "${var.prefix}-ecs-clean"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.ecs_execution.arn

  container_definitions = jsonencode([{
    name  = "clean-container"
    image = "${aws_ecr_repository.poc.repository_url}:image-clean"
    portMappings = [{ containerPort = 80, protocol = "tcp" }]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = "/ecs/${var.prefix}-clean"
        "awslogs-region"        = var.aws_region
        "awslogs-stream-prefix" = "ecs"
      }
    }
  }])

  tags = var.tags
}

resource "aws_cloudwatch_log_group" "ecs_clean" {
  name              = "/ecs/${var.prefix}-clean"
  retention_in_days = 7
  tags              = var.tags
}

# ──────────────────────────────────────────────────────────────────────────────
# ECS Services
# ──────────────────────────────────────────────────────────────────────────────

resource "aws_ecs_service" "vuln" {
  name            = "${var.prefix}-ecs-vuln"
  cluster         = aws_ecs_cluster.poc.id
  task_definition = aws_ecs_task_definition.vuln.arn
  desired_count   = 1
  launch_type     = "FARGATE"

  network_configuration {
    subnets          = [aws_subnet.expose.id]
    security_groups  = [aws_security_group.expose.id]
    assign_public_ip = true
  }

  tags = var.tags
}

resource "aws_ecs_service" "secret" {
  name            = "${var.prefix}-ecs-secret"
  cluster         = aws_ecs_cluster.poc.id
  task_definition = aws_ecs_task_definition.secret.arn
  desired_count   = 1
  launch_type     = "FARGATE"

  network_configuration {
    subnets          = [aws_subnet.expose.id]
    security_groups  = [aws_security_group.expose.id]
    assign_public_ip = true
  }

  tags = var.tags
}

resource "aws_ecs_service" "clean" {
  name            = "${var.prefix}-ecs-clean"
  cluster         = aws_ecs_cluster.poc.id
  task_definition = aws_ecs_task_definition.clean.arn
  desired_count   = 1
  launch_type     = "FARGATE"

  network_configuration {
    subnets         = [aws_subnet.restreint.id]
    security_groups = [aws_security_group.restreint.id]
  }

  tags = var.tags
}

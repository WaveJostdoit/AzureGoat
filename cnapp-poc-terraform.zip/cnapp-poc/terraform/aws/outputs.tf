output "ec2_vuln_public_ip" {
  description = "Public IP of ec2-vuln (CWPP-01, SS-02)"
  value       = aws_instance.ec2_vuln.public_ip
}

output "ec2_secret_public_ip" {
  description = "Public IP of ec2-secret (SS-02)"
  value       = aws_instance.ec2_secret.public_ip
}

output "lambda_api_endpoint" {
  description = "Public API Gateway URL for lambda-vuln (CWPP-03)"
  value       = aws_apigatewayv2_api.poc.api_endpoint
}

output "ecr_repository_url" {
  description = "ECR repository URL – used by build_images.sh"
  value       = aws_ecr_repository.poc.repository_url
}

output "cloudtrail_bucket" {
  description = "S3 bucket storing CloudTrail logs"
  value       = aws_s3_bucket.cloudtrail.id
}

output "drift_bucket" {
  description = "S3 bucket used for IaC drift test (IAC-06)"
  value       = aws_s3_bucket.drift_target.id
}

output "aws_account_id" {
  description = "Current AWS account ID"
  value       = data.aws_caller_identity.current.account_id
}

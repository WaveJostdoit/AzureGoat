data "archive_file" "lambda" {
  type        = "zip"
  source_dir  = "${path.module}/../../pipelines/lambda"
  output_path = "${path.module}/lambda_package.zip"
}

# ──────────────────────────────────────────────────────────────────────────────
# Lambda – vulnérable (CWPP-03, SS-02)
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_lambda_function" "vuln" {
  filename         = data.archive_file.lambda.output_path
  source_code_hash = data.archive_file.lambda.output_base64sha256
  function_name    = "${var.prefix}-lambda-vuln"
  role             = aws_iam_role.lambda_exec.arn
  handler          = "handler.lambda_handler"
  runtime          = "python3.9" # Version non la plus récente – intentionnel

  environment {
    variables = {
      # Secrets en variables d'env – SS-02 intentionnel
      DB_PASSWORD = "SuperSecret123"
      API_KEY     = "AKIAFAKEKEY123456"
    }
  }

  tags = var.tags
}

# ──────────────────────────────────────────────────────────────────────────────
# API Gateway HTTP – public, sans auth (CWPP-03)
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_apigatewayv2_api" "poc" {
  name          = "${var.prefix}-api"
  protocol_type = "HTTP"
  tags          = var.tags
}

resource "aws_apigatewayv2_integration" "lambda" {
  api_id             = aws_apigatewayv2_api.poc.id
  integration_type   = "AWS_PROXY"
  integration_uri    = aws_lambda_function.vuln.invoke_arn
  integration_method = "POST"
}

# Route sans authorization_type → trigger public intentionnel (CWPP-03)
resource "aws_apigatewayv2_route" "default" {
  api_id    = aws_apigatewayv2_api.poc.id
  route_key = "GET /"
  target    = "integrations/${aws_apigatewayv2_integration.lambda.id}"
}

resource "aws_apigatewayv2_stage" "default" {
  api_id      = aws_apigatewayv2_api.poc.id
  name        = "$default"
  auto_deploy = true
  tags        = var.tags
}

resource "aws_lambda_permission" "apigw" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.vuln.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.poc.execution_arn}/*/*"
}

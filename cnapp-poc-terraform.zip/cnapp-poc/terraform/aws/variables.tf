variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "eu-west-1"
}

variable "prefix" {
  description = "Prefix for all resource names"
  type        = string
  default     = "cnapp-poc"
}

variable "az" {
  description = "Availability zone"
  type        = string
  default     = "eu-west-1a"
}

variable "ssh_public_key" {
  description = "SSH public key for EC2 instances"
  type        = string
}

variable "tags" {
  description = "Common tags applied to all resources"
  type        = map(string)
  default = {
    Project     = "cnapp-poc"
    Environment = "poc"
    ManagedBy   = "terraform"
  }
}

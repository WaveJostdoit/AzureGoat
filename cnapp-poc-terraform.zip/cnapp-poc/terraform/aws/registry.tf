resource "aws_ecr_repository" "poc" {
  name                 = "${var.prefix}-registry"
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = var.tags
}

# Politique de lifecycle : garder seulement les 10 dernières images par tag
resource "aws_ecr_lifecycle_policy" "poc" {
  repository = aws_ecr_repository.poc.name

  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep last 10 images"
      selection = {
        tagStatus   = "any"
        countType   = "imageCountMoreThan"
        countNumber = 10
      }
      action = { type = "expire" }
    }]
  })
}

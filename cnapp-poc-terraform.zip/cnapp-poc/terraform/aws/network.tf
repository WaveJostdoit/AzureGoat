# ──────────────────────────────────────────────────────────────────────────────
# VPC
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_vpc" "main" {
  cidr_block           = "10.10.0.0/16"
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags                 = { Name = "${var.prefix}-vpc" }
}

resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.main.id
  tags   = { Name = "${var.prefix}-igw" }
}

# ──────────────────────────────────────────────────────────────────────────────
# Subnets
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_subnet" "expose" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.10.1.0/24"
  availability_zone       = var.az
  map_public_ip_on_launch = true
  tags                    = { Name = "${var.prefix}-subnet-expose" }
}

resource "aws_subnet" "restreint" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.10.2.0/24"
  availability_zone = var.az
  tags              = { Name = "${var.prefix}-subnet-restreint" }
}

# ──────────────────────────────────────────────────────────────────────────────
# Route tables
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_route_table" "expose" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.igw.id
  }

  tags = { Name = "${var.prefix}-rtb-expose" }
}

resource "aws_route_table_association" "expose" {
  subnet_id      = aws_subnet.expose.id
  route_table_id = aws_route_table.expose.id
}

# ──────────────────────────────────────────────────────────────────────────────
# Security Groups
# ──────────────────────────────────────────────────────────────────────────────

# INTENTIONNELLEMENT OUVERT – tests CWPP-01/02/03, IAC-01/03
resource "aws_security_group" "expose" {
  name        = "${var.prefix}-sg-expose"
  description = "POC – intentionally open SG (CWPP/IAC misconfiguration test)"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "SSH world-open – intentional PoC misconfiguration (CWPP-01, IAC-01)"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "HTTP world-open – intentional (CWPP-01)"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "App port 8080"
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.prefix}-sg-expose" }
}

resource "aws_security_group" "restreint" {
  name        = "${var.prefix}-sg-restrict"
  description = "POC – restricted SG, no inbound from Internet"
  vpc_id      = aws_vpc.main.id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.prefix}-sg-restrict" }
}

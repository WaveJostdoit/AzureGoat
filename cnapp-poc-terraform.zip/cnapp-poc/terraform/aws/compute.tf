# ──────────────────────────────────────────────────────────────────────────────
# AMI + Key pair
# ──────────────────────────────────────────────────────────────────────────────

data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical

  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]
  }
}

resource "aws_key_pair" "poc" {
  key_name   = "${var.prefix}-key"
  public_key = var.ssh_public_key
}

# ──────────────────────────────────────────────────────────────────────────────
# EC2 – Vulnérable (CWPP-01, SS-02)
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_instance" "ec2_vuln" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = "t3.micro"
  subnet_id              = aws_subnet.expose.id
  vpc_security_group_ids = [aws_security_group.expose.id]
  key_name               = aws_key_pair.poc.key_name
  iam_instance_profile   = aws_iam_instance_profile.sa_overprivileged.name

  user_data = base64encode(<<-EOF
    #!/bin/bash
    # Désactiver les mises à jour automatiques pour conserver l'état vulnérable
    systemctl disable unattended-upgrades || true
    apt-get update -y
    # Package Apache volontairement non patché (CWPP-01 – CVE connues sur 2.4.52)
    apt-get install -y --allow-downgrades apache2
    systemctl enable apache2
    # SSH root login activé – misconfiguration intentionnelle (CWPP-01)
    sed -i 's/#PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
    sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
    systemctl restart sshd
  EOF
  )

  tags = merge(var.tags, {
    Name       = "${var.prefix}-ec2-vuln"
    Role       = "vulnerable"
    repo_url   = "https://github.com/your-org/cnapp-poc"
    commit_sha = "to-be-replaced-at-deploy"
  })
}

# ──────────────────────────────────────────────────────────────────────────────
# EC2 – Secret exposé (SS-02)
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_instance" "ec2_secret" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = "t3.micro"
  subnet_id              = aws_subnet.expose.id
  vpc_security_group_ids = [aws_security_group.expose.id]
  key_name               = aws_key_pair.poc.key_name
  iam_instance_profile   = aws_iam_instance_profile.sa_standard.name

  user_data = base64encode(<<-EOF
    #!/bin/bash
    apt-get update -y
    # Secret en variable d'environnement (SS-02 – intentionnel)
    echo 'AWS_SECRET_ACCESS_KEY=AKIAFAKEKEY123456' >> /etc/environment
    echo 'DB_PASSWORD=SuperSecret123'              >> /etc/environment
    # Secret dans fichier avec permissions trop larges (SS-02 – intentionnel)
    mkdir -p /home/ubuntu
    echo "db_password=SuperSecret123"   >  /home/ubuntu/config.txt
    echo "api_key=fake-api-key-do-not-use" >> /home/ubuntu/config.txt
    chmod 777 /home/ubuntu/config.txt
    chown ubuntu:ubuntu /home/ubuntu/config.txt
  EOF
  )

  tags = merge(var.tags, {
    Name = "${var.prefix}-ec2-secret"
    Role = "secret-exposed"
  })
}

# ──────────────────────────────────────────────────────────────────────────────
# EC2 – Saine / référence
# ──────────────────────────────────────────────────────────────────────────────
resource "aws_instance" "ec2_clean" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = "t3.micro"
  subnet_id              = aws_subnet.restreint.id
  vpc_security_group_ids = [aws_security_group.restreint.id]
  key_name               = aws_key_pair.poc.key_name

  user_data = base64encode(<<-EOF
    #!/bin/bash
    apt-get update -y && apt-get upgrade -y
    sed -i 's/#PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
    systemctl restart sshd
  EOF
  )

  tags = merge(var.tags, {
    Name = "${var.prefix}-ec2-clean"
    Role = "clean-reference"
  })
}

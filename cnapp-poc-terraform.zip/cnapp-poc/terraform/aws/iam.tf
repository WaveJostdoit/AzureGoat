# ──────────────────────────────────────────────────────────────────────────────
# Machine identities
# ──────────────────────────────────────────────────────────────────────────────

resource "aws_iam_role" "sa_overprivileged" {
  name = "${var.prefix}-iam-role-sa-overprivileged"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = ["ec2.amazonaws.com", "ecs-tasks.amazonaws.com", "lambda.amazonaws.com"] }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "sa_overprivileged_readonly" {
  role       = aws_iam_role.sa_overprivileged.name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

# Permissions IAM excessives – CIEM-05/06 intentionnel
resource "aws_iam_role_policy" "sa_overprivileged_iam_excess" {
  name = "iam-excess"
  role = aws_iam_role.sa_overprivileged.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["iam:List*", "iam:Get*", "sts:AssumeRole"]
      Resource = "*"
    }]
  })
}

resource "aws_iam_instance_profile" "sa_overprivileged" {
  name = "${var.prefix}-overprivileged-profile"
  role = aws_iam_role.sa_overprivileged.name
}

# ─── Standard machine identity ────────────────────────────────────────────────
resource "aws_iam_role" "sa_standard" {
  name = "${var.prefix}-iam-role-sa-standard"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = ["ec2.amazonaws.com", "ecs-tasks.amazonaws.com", "lambda.amazonaws.com"] }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "sa_standard_s3" {
  role       = aws_iam_role.sa_standard.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess"
}

resource "aws_iam_instance_profile" "sa_standard" {
  name = "${var.prefix}-standard-profile"
  role = aws_iam_role.sa_standard.name
}

# ──────────────────────────────────────────────────────────────────────────────
# Human identities – Groups
# ──────────────────────────────────────────────────────────────────────────────

resource "aws_iam_group" "developers" {
  name = "${var.prefix}-developers"
}

resource "aws_iam_group" "security_analysts" {
  name = "${var.prefix}-security-analysts"
}

resource "aws_iam_group" "admins" {
  name = "${var.prefix}-admins"
}

resource "aws_iam_group" "readonly" {
  name = "${var.prefix}-readonly"
}

resource "aws_iam_group_policy_attachment" "developers_poweruser" {
  group      = aws_iam_group.developers.name
  policy_arn = "arn:aws:iam::aws:policy/PowerUserAccess"
}

# CIEM-04 : groupe admin détectable comme high-privilege
resource "aws_iam_group_policy_attachment" "admins_full" {
  group      = aws_iam_group.admins.name
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
}

resource "aws_iam_group_policy_attachment" "readonly" {
  group      = aws_iam_group.readonly.name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

# ──────────────────────────────────────────────────────────────────────────────
# Human identities – Users
# ──────────────────────────────────────────────────────────────────────────────

resource "aws_iam_user" "standard" {
  count = 3
  name  = "${var.prefix}-user-standard-${count.index + 1}"
  tags  = merge(var.tags, { Role = "standard" })
}

resource "aws_iam_user" "overprivileged" {
  name = "${var.prefix}-user-overprivileged"
  tags = merge(var.tags, { Role = "overprivileged" })
}

# Appartient à 2 groupes → CIEM-03 (effective permissions)
resource "aws_iam_user" "multirole" {
  name = "${var.prefix}-user-multirole"
  tags = merge(var.tags, { Role = "multirole" })
}

# CIEM-04 : admin détectable
resource "aws_iam_user" "admin" {
  name = "${var.prefix}-user-admin"
  tags = merge(var.tags, { Role = "admin" })
}

# CIEM-04/07 : break-glass, normalement inutilisé
resource "aws_iam_user" "breakglass" {
  name = "${var.prefix}-user-break-glass"
  tags = merge(var.tags, { Role = "break-glass" })
}

resource "aws_iam_user" "readonly" {
  count = 2
  name  = "${var.prefix}-user-readonly-${count.index + 1}"
  tags  = merge(var.tags, { Role = "readonly" })
}

# ──────────────────────────────────────────────────────────────────────────────
# Group memberships
# ──────────────────────────────────────────────────────────────────────────────

resource "aws_iam_user_group_membership" "standard_dev" {
  count  = 3
  user   = aws_iam_user.standard[count.index].name
  groups = [aws_iam_group.developers.name]
}

# Double appartenance developers + admins → CIEM-05 (permission overlap)
resource "aws_iam_user_group_membership" "overprivileged" {
  user   = aws_iam_user.overprivileged.name
  groups = [aws_iam_group.developers.name, aws_iam_group.admins.name]
}

resource "aws_iam_user_group_membership" "admin" {
  user   = aws_iam_user.admin.name
  groups = [aws_iam_group.admins.name]
}

# developers + readonly → CIEM-03
resource "aws_iam_user_group_membership" "multirole" {
  user   = aws_iam_user.multirole.name
  groups = [aws_iam_group.developers.name, aws_iam_group.readonly.name]
}

resource "aws_iam_user_group_membership" "readonly" {
  count  = 2
  user   = aws_iam_user.readonly[count.index].name
  groups = [aws_iam_group.readonly.name]
}

# Permission directe AdministratorAccess sur break-glass → CIEM-04/07
resource "aws_iam_user_policy_attachment" "breakglass_admin" {
  user       = aws_iam_user.breakglass.name
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
}

# ──────────────────────────────────────────────────────────────────────────────
# Lambda execution role (over-privileged – CWPP-03)
# ──────────────────────────────────────────────────────────────────────────────

resource "aws_iam_role" "lambda_exec" {
  name = "${var.prefix}-lambda-exec-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = var.tags
}

# AdministratorAccess sur Lambda → permission excessive intentionnelle (CWPP-03)
resource "aws_iam_role_policy_attachment" "lambda_exec_admin" {
  role       = aws_iam_role.lambda_exec.name
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
}

resource "aws_iam_role_policy_attachment" "lambda_exec_logs" {
  role       = aws_iam_role.lambda_exec.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

# Module compute réutilisable
# Contient des misconfigurations intentionnelles pour tester IAC-02
# (détection des issues dans les modules référencés depuis le fichier parent).

variable "vpc_id"        { type = string }
variable "subnet_id"     { type = string }
variable "ami_id"        { type = string }
variable "key_name"      { type = string }
variable "instance_type" { type = string; default = "t3.micro" }
variable "prefix"        { type = string; default = "cnapp-module" }
variable "tags"          { type = map(string); default = {} }

resource "aws_security_group" "module_sg" {
  name   = "${var.prefix}-module-sg"
  vpc_id = var.vpc_id

  # MISCONFIGURATION INTENTIONNELLE – tous les ports ouverts (IAC-02)
  ingress {
    from_port   = 0
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = var.tags
}

resource "aws_instance" "compute" {
  ami           = var.ami_id
  instance_type = var.instance_type
  subnet_id     = var.subnet_id
  key_name      = var.key_name

  vpc_security_group_ids = [aws_security_group.module_sg.id]

  root_block_device {
    encrypted = false # MISCONFIGURATION INTENTIONNELLE – pas de chiffrement (IAC-01/03)
  }

  # Tag ManagedBy absent intentionnellement pour test IAC-03 (tagging policy)
  tags = merge(var.tags, { Name = "${var.prefix}-module-compute" })
}

output "instance_id"        { value = aws_instance.compute.id }
output "security_group_id"  { value = aws_security_group.module_sg.id }

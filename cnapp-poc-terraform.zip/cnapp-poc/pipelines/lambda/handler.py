"""
Lambda function – intentionnellement vulnérable pour les tests CNAPP PoC.

Vulnérabilités intentionnelles :
  - CWPP-03 : trigger HTTP public sans authentification, dépendance vulnérable
  - SS-01/02 : secret hardcodé détectable par scan statique + présent en env
"""

import json
import os

# Secret hardcodé – détectable par scan statique (SS-01)
# noqa: S105
HARDCODED_API_KEY = "AKIAFAKEKEY123456789"      # noqa: S105
HARDCODED_DB_PASS = "hardcoded-secret-poc-only"  # noqa: S105


def lambda_handler(event, context):
    """
    Handler HTTP public – entrée non filtrée, secrets exposés dans la réponse
    à des fins de démonstration PoC uniquement.
    """
    params = (event.get("queryStringParameters") or {})
    name = params.get("name", "world")

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "message": f"Hello, {name}!",
            # Exposition de la variable d'env en réponse – SS-02 PoC only
            "env_db": os.environ.get("DB_PASSWORD", "not-set"),
        }),
    }

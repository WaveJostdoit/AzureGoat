#!/usr/bin/env bash
# inject_git_secret.sh – Injecte un faux secret dans le repo et son historique git
# pour tester SS-01 (scan statique) et SS-07 (scan historique git).
#
# Le script crée 2 commits :
#   1. Commit qui ajoute un fichier .env.test avec de faux secrets
#   2. Commit qui supprime ce fichier (mais le secret reste dans l'historique)
#
# Usage: bash scripts/inject_git_secret.sh [--push]
set -euo pipefail

PUSH=false
[[ "${1:-}" == "--push" ]] && PUSH=true

echo "=== Injection de faux secrets pour tests SS-01 / SS-07 ==="
echo "    Ces secrets sont FICTIFS et n'ont aucune valeur réelle."

# ─── Commit 1 : ajout du fichier avec faux secrets ───────────────────────────
cat > .env.test <<'EOF'
# ===========================================================
# FAUX SECRETS – USAGE TEST CNAPP POC UNIQUEMENT
# Ces valeurs sont fictives et n'ont aucune valeur en production.
# ===========================================================
AWS_ACCESS_KEY_ID=AKIAFAKEACCESSKEY12345
AWS_SECRET_ACCESS_KEY=FakeSecretKey/AAABBBCCC+DDD123456789poc000
GITHUB_TOKEN=ghp_FakeGithubPersonalToken1234567890ab
DB_PASSWORD=SuperFakePassword123!
STRIPE_API_KEY=sk_live_FakeStripeKey1234567890abcdef
EOF

git add .env.test
git commit -m "chore: add env config [CNAPP-TEST contains fake secrets for SS-01/SS-07]"
echo "✅ Commit 1/2 : faux secrets ajoutés"

# ─── Commit 2 : suppression du fichier (secret reste dans l'historique) ──────
rm .env.test
git add .env.test
git commit -m "fix: remove env file – secret still in git history for SS-07 test"
echo "✅ Commit 2/2 : fichier supprimé (secret présent dans l'historique)"

if [[ "$PUSH" == "true" ]]; then
  git push
  echo "✅ Pushed to remote"
else
  echo ""
  echo "Pour pousser : git push  (ou relancez avec --push)"
fi

echo ""
echo "=== Terminé. La CNAPP devrait détecter le secret dans l'historique git (SS-07). ==="

#!/usr/bin/env bash
# trigger_drift.sh – Crée un drift IaC sur AWS et Azure (IAC-06)
# après le déploiement Terraform, pour tester la détection de drift par la CNAPP.
#
# Drift AWS  : désactive le versioning du bucket S3 drift_target (était Enabled)
# Drift Azure: désactive https_only du Storage Account drift_target (était true)
set -euo pipefail

AWS_REGION="${AWS_REGION:-eu-west-1}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

echo "=== Récupération des outputs Terraform ==="
DRIFT_BUCKET=$(terraform -chdir="$REPO_ROOT/terraform/aws"   output -raw drift_bucket)
AZURE_RG=$(terraform     -chdir="$REPO_ROOT/terraform/azure"  output -raw resource_group_name)
DRIFT_SA=$(terraform     -chdir="$REPO_ROOT/terraform/azure"  output -raw drift_storage_account)

echo "AWS  drift bucket : $DRIFT_BUCKET"
echo "Azure drift SA    : $DRIFT_SA  (RG: $AZURE_RG)"

echo ""
echo "=== [AWS] Désactivation du versioning S3 (IAC-06) ==="
aws s3api put-bucket-versioning \
  --region "$AWS_REGION" \
  --bucket "$DRIFT_BUCKET" \
  --versioning-configuration Status=Suspended
echo "✅ S3 versioning suspendu – drift créé"

echo ""
echo "=== [Azure] Désactivation de https_only (IAC-06) ==="
az storage account update \
  --name           "$DRIFT_SA" \
  --resource-group "$AZURE_RG" \
  --https-only     false
echo "✅ https_only=false – drift créé"

echo ""
echo "=== Drift appliqué. Attendez ~5–15 min puis vérifiez dans la CNAPP (IAC-06). ==="
echo "    Pour rétablir l'état Terraform : terraform apply (dans aws/ et azure/)"

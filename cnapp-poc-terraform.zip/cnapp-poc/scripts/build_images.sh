#!/usr/bin/env bash
# build_images.sh – Build et push des 3 images Docker vers ECR (AWS) et ACR (Azure)
# Usage: bash scripts/build_images.sh
set -euo pipefail

AWS_REGION="${AWS_REGION:-eu-west-1}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

# ─── Récupérer les URLs depuis les outputs Terraform ──────────────────────────
ECR_URL=$(terraform -chdir="$REPO_ROOT/terraform/aws"    output -raw ecr_repository_url)
ACR_URL=$(terraform -chdir="$REPO_ROOT/terraform/azure"  output -raw acr_login_server)
ACR_USER=$(terraform -chdir="$REPO_ROOT/terraform/azure" output -raw acr_admin_username 2>/dev/null || echo "")

echo "ECR : $ECR_URL"
echo "ACR : $ACR_URL"

# ─── Login ────────────────────────────────────────────────────────────────────
aws ecr get-login-password --region "$AWS_REGION" \
  | docker login --username AWS --password-stdin "$ECR_URL"

az acr login --name "$(echo "$ACR_URL" | cut -d. -f1)"

# ─── Image 1 : Vulnérable (CWPP-02/05) ───────────────────────────────────────
cat > /tmp/Dockerfile.vuln <<'EOF'
# Image ancienne volontairement non patchée (CWPP-02/05 – CVEs connues sur debian:9)
FROM debian:9
RUN apt-get update && apt-get install -y curl wget apache2 --no-install-recommends
# Secret dans ENV (SS-04 – intentionnel)
ENV DB_PASSWORD="SuperSecret123"
ENV API_KEY="fake-api-key-vuln-image"
EXPOSE 80
CMD ["apache2ctl", "-D", "FOREGROUND"]
EOF

docker build -t image-vuln -f /tmp/Dockerfile.vuln .
docker tag image-vuln "$ECR_URL:image-vuln"
docker push "$ECR_URL:image-vuln"
docker tag image-vuln "$ACR_URL/image-vuln:latest"
docker push "$ACR_URL/image-vuln:latest"
echo "✅ image-vuln pushed"

# ─── Image 2 : Secret embarqué (SS-04) ───────────────────────────────────────
cat > /tmp/Dockerfile.secret <<'EOF'
FROM ubuntu:20.04
RUN apt-get update && apt-get install -y python3 --no-install-recommends
# Secret hardcodé dans le layer de l'image (SS-04 – intentionnel)
RUN mkdir -p /app && \
    echo "password=HardcodedSecretInImage123"   > /app/config.cfg && \
    echo "api_key=secret-key-in-image-layer"   >> /app/config.cfg
ENV DATABASE_URL="postgres://user:SecretPassword123@db:5432/mydb"
EXPOSE 80
CMD ["python3", "-m", "http.server", "80"]
EOF

docker build -t image-secret -f /tmp/Dockerfile.secret .
docker tag image-secret "$ECR_URL:image-secret"
docker push "$ECR_URL:image-secret"
docker tag image-secret "$ACR_URL/image-secret:latest"
docker push "$ACR_URL/image-secret:latest"
echo "✅ image-secret pushed"

# ─── Image 3 : Saine / référence ──────────────────────────────────────────────
cat > /tmp/Dockerfile.clean <<'EOF'
FROM python:3.11-slim
RUN useradd -m appuser
USER appuser
WORKDIR /app
EXPOSE 80
CMD ["python3", "-m", "http.server", "80"]
EOF

docker build -t image-clean -f /tmp/Dockerfile.clean .
docker tag image-clean "$ECR_URL:image-clean"
docker push "$ECR_URL:image-clean"
docker tag image-clean "$ACR_URL/image-clean:latest"
docker push "$ACR_URL/image-clean:latest"
echo "✅ image-clean pushed"

echo ""
echo "🎉 All 3 images pushed to ECR and ACR."
